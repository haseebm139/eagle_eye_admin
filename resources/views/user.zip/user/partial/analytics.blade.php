<div class="container  d-flex  gap-3 justify-content-center align-items-center">
    <div class="row">
        <div class="col-lg-4 col-md-2 col-sm-12">
             <div class="d-flex flex-column justify-content-center align-items-center box ">
                <h1 class="price">3K</h1>
                <p class="indentity">Customer</p>
            </div>
        </div>
        <div class="col-lg-4 col-md-2 col-sm-12">
              <div class="d-flex flex-column justify-content-center align-items-center box ">
                <h1 class="price">56K</h1>
                <p class="indentity">Prints & Signs in last 12 Months </p>
            </div>
        </div>
        <div class="col-lg-4 col-md-2 col-sm-12">
            <div class="d-flex flex-column justify-content-center align-items-center box ">
                    <h1 class="price">22</h1>
                    <p class="indentity">States</p>
             </div>
        </div>
    </div>
   


 

    
</div>
