const interfaceTranslations = {
  selectedCountryAriaLabel: "ఎంచుకున్న దేశం",
  noCountrySelected: "ఏ దేశం ఎంచుకోబడలేదు",
  countryListAriaLabel: "దేశాల జాబితా",
  searchPlaceholder: "వెతకండి",
  zeroSearchResults: "ఎటువంటి ఫలితాలు లభించలేదు",
  oneSearchResult: "1 ఫలితం కనుగొనబడింది",
  multipleSearchResults: "${count} ఫలితాలు కనుగొనబడ్డాయి",
  // additional countries (not supported by country-list library)
  ac: "అసెన్షన్ ద్వీపం",
  xk: "కొసోవో"
};
export default interfaceTranslations;
