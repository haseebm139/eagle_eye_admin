const interfaceTranslations = {
  selectedCountryAriaLabel: "নির্বাচিত দেশ",
  noCountrySelected: "কোনো দেশ নির্বাচন করা হয়নি",
  countryListAriaLabel: "দেশের তালিকা",
  searchPlaceholder: "অনুসন্ধান করুন",
  zeroSearchResults: "কোন ফলাফল পাওয়া যায়নি",
  oneSearchResult: "1টি ফলাফল পাওয়া গেছে",
  multipleSearchResults: "${count} ফলাফল পাওয়া গেছে",
  // additional countries (not supported by country-list library)
  ac: "অ্যাসেনশন দ্বীপ",
  xk: "কসোভো"
};
export default interfaceTranslations;
